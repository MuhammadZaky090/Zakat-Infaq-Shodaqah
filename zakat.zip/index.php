<?php
header('location: main.php?module=landing_page');
?>